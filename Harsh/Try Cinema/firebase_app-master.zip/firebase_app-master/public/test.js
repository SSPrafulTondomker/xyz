(function(){


  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDj-jKoxVrmZc6erMMRChEWb37vR5GpINk",
    authDomain: "hello-98fd4.firebaseapp.com",
    databaseURL: "https://hello-98fd4.firebaseio.com",
    storageBucket: "hello-98fd4.appspot.com",
    messagingSenderId: "27109621092"
  };
  firebase.initializeApp(config);
  angular
      .module('TextEditor',['firebase','ngSanitize'])
      
      .controller('MyCtrl',['$scope','$firebaseArray',function($scope,$firebaseArray)
{

  
   $scope.rootref=firebase.database().ref();
   console.log(new Date(Date.now()).toLocaleString());
  $scope.list=$firebaseArray($scope.rootref);
  $scope.addimage=function(url,id)
  {
    if( document.getElementById(id+'image')!=null)
    {
      document.getElementById(id+'image').remove();}
    //dynamically add an image and set its attribute
    var img=document.createElement("img");
    img.src=url;
    img.id=id+"image";
    img.setAttribute("height", "300");
    img.setAttribute("width", "350");
  
    var foo = document.getElementById(id);
    foo.appendChild(img);
}

  
  $scope.show=function(blog){
    
   
    $scope.storageRef = firebase.storage().ref("images/"+blog.$id+".jpg");
    $scope.storageRef.getDownloadURL().then(function(url) {
    console.log(url);
    $scope.addimage(url,blog.$id);
}, function(error) {
  
  
    return false;
})
  }

}
      ] );



}());
